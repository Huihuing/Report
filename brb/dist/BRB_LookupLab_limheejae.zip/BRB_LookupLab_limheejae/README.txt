BR-B Lookup Lab / Author: limheejae
========================================

[실행 방법]
1. ZIP을 임의의 새 폴더에 압축 해제합니다.
2. BRB_LookupLab_limheejae 폴더의 index.html을 더블 클릭합니다.
3. 브라우저에서 자료 크기와 조회 위치를 선택하고 "측정값 비교하기"를 누릅니다.
4. 숫자(-1, 0, 9999 등)를 입력해 존재 여부를 확인합니다. 글자나 빈 값도 시도해 보세요.

[통과 기준]
- 100 / 1000 / 10000개와 부재 / 첫 위치 / 끝 위치 9가지 비교를 전환할 수 있습니다.
- 정수 10000개, 부재 조건에서 list 64935.154ns, set 18.132ns가 표시됩니다.
- 숫자 0은 존재, -1은 부재로 판정합니다. 잘못된 입력은 앱 중단 없이 안내합니다.

[포함 파일]
- index.html, styles.css, app.js, data/research.js : 앱 실행 필수 파일
- data/t10_analysis_original.json : 원본 T10 실측 요약 자료
- SUBMISSION.md : 과제 제출 안내

[주의]
- 인터넷 연결/계정/비밀번호/API 키/별도 설치가 필요하지 않습니다.
- 상단의 T10 논문 및 BR-A 포트폴리오 링크는 공개 사이트에서 이용하세요:
  https://report-huihuing.vercel.app/t10/
  https://report-huihuing.vercel.app/bra/
- 원자료는 CPython 3.13.5 Linux 실험으로 조회 시간 보장을 뜻하지 않습니다.
- 새 시크릿 창 및 실제 동료 후기 검사는 사용자가 별도로 확인해야 합니다.
